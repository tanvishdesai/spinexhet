"""XAI Disagreement Benchmark v2.

Extended benchmark script that evaluates:
  1. Faithfulness (deletion AUC, insertion AUC)
  2. Agreement (pairwise Spearman, Top-20% IoU)
  3. Consistency (augmentation stability)
  4. Clinical alignment (condition-specific proxy ROI)

Outputs per-sample CSV results and aggregate summaries for paper figures.
"""

from __future__ import annotations

import argparse
import time
from pathlib import Path
import sys

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader
from torchvision import transforms
from tqdm.auto import tqdm

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from spine_xnet.config import load_config_with_base
from spine_xnet.constants import DEFAULT_CONCEPTS
from spine_xnet.data.dataset import RSNACropDataset, load_manifest_for_fold
from spine_xnet.evaluation.metrics import normalize_map, spearman_corr, topk_iou
from spine_xnet.evaluation.xai import (
    attribution_agreement,
    deletion_insertion_auc,
    proxy_roi_alignment,
    run_attribution_method,
)
from spine_xnet.models import build_model
from spine_xnet.utils import seed_everything, to_device, write_json


# ── CLI ──────────────────────────────────────────────────────────────────────

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="XAI Disagreement Benchmark v2.")
    p.add_argument("--config", type=Path, required=True)
    p.add_argument("--checkpoint", type=Path, required=True)
    p.add_argument("--manifest", type=Path, default=None)
    p.add_argument("--fold", type=int, default=None)
    p.add_argument("--output-dir", type=Path, required=True)
    p.add_argument("--max-samples", type=int, default=500)
    p.add_argument(
        "--methods", nargs="+",
        default=["gradcam", "gradcam++", "scorecam", "integrated_gradients", "lrp", "lime", "shap"],
    )
    p.add_argument("--faithfulness-steps", type=int, default=20)
    p.add_argument("--crop-root", type=Path, default=None)
    p.add_argument("--cache-dir", type=Path, default=None)
    p.add_argument("--save-maps", action="store_true", help="Save attribution maps as .npy")
    p.add_argument("--consistency-augmentations", type=int, default=3,
                    help="Number of augmented copies per image for consistency eval")
    p.add_argument("--skip-consistency", action="store_true")
    p.add_argument("--skip-faithfulness", action="store_true")
    return p.parse_args()


# ── Consistency helpers ──────────────────────────────────────────────────────

CONSISTENCY_AUGMENTATIONS = [
    transforms.RandomRotation(degrees=5),
    transforms.RandomAffine(degrees=0, translate=(0.03, 0.03)),
    transforms.ColorJitter(brightness=0.1, contrast=0.1),
]


def augment_image(image: torch.Tensor, aug_idx: int) -> torch.Tensor:
    """Apply a deterministic augmentation to a CHW tensor."""
    aug = CONSISTENCY_AUGMENTATIONS[aug_idx % len(CONSISTENCY_AUGMENTATIONS)]
    return aug(image)


def compute_consistency_for_sample(
    model: torch.nn.Module,
    image: torch.Tensor,
    condition_idx: int,
    level_idx: int,
    target: int,
    method: str,
    n_augmentations: int = 3,
) -> float:
    """Average Top-20% IoU between original and augmented attributions."""
    original_attr = run_attribution_method(method, model, image, condition_idx, level_idx, target)
    ious = []
    for i in range(n_augmentations):
        aug_image = augment_image(image.squeeze(0), i).unsqueeze(0).to(image.device)
        try:
            aug_attr = run_attribution_method(method, model, aug_image, condition_idx, level_idx, target)
            ious.append(topk_iou(original_attr, aug_attr, top_fraction=0.20))
        except Exception:
            continue
    return float(np.mean(ious)) if ious else float("nan")


# ── Main ─────────────────────────────────────────────────────────────────────

def main() -> None:
    args = parse_args()
    cfg = load_config_with_base(args.config)
    seed_everything(int(cfg.get("seed", 42)))

    data_cfg = cfg.get("data", {})
    if args.crop_root is not None:
        data_cfg["crop_root"] = str(args.crop_root)
    if args.cache_dir is not None:
        data_cfg["cache_dir"] = str(args.cache_dir)

    manifest = args.manifest or Path(data_cfg["manifest"])
    fold = args.fold if args.fold is not None else int(data_cfg.get("fold", 0))
    _, val_df = load_manifest_for_fold(manifest, fold=fold, fold_col=data_cfg.get("fold_col", "fold"))
    val_df = val_df.head(args.max_samples).reset_index(drop=True)

    concept_columns = data_cfg.get("concept_columns", DEFAULT_CONCEPTS)
    dataset = RSNACropDataset(
        val_df,
        image_size=int(data_cfg.get("image_size", 224)),
        train=False,
        concept_columns=concept_columns,
        crop_root=data_cfg.get("crop_root"),
        manifest_path=manifest,
        require_crops=bool(data_cfg.get("require_crops", False)),
        cache_dir=data_cfg.get("cache_dir"),
    )
    loader = DataLoader(dataset, batch_size=1, shuffle=False, num_workers=0)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = build_model(cfg, num_concepts=len(dataset.concept_columns)).to(device)
    ckpt = torch.load(args.checkpoint, map_location=device)
    model.load_state_dict(ckpt["model"], strict=True)
    model.eval()

    args.output_dir.mkdir(parents=True, exist_ok=True)
    maps_dir = args.output_dir / "attribution_maps" if args.save_maps else None
    if maps_dir:
        maps_dir.mkdir(parents=True, exist_ok=True)

    faithfulness_rows = []
    agreement_rows = []
    consistency_rows = []
    clinical_rows = []
    skipped: dict[str, str] = {}
    start_time = time.monotonic()

    for sample_idx, batch in enumerate(tqdm(loader, desc="xai_v2")):
        batch = to_device(batch, device)
        sample_id = batch["sample_id"][0]
        condition = batch["condition"][0] if "condition" in batch else None
        condition_idx = int(batch["condition_idx"].item())
        level_idx = int(batch["level_idx"].item())
        label = int(batch["label"].item())

        with torch.no_grad():
            outputs = model(batch["image"], batch["condition_idx"], batch["level_idx"])
            target = int(torch.softmax(outputs["logits"], dim=1).argmax(dim=1).item())

        attributions: dict[str, np.ndarray] = {}

        # ── Compute attributions ─────────────────────────────────────────
        for method in args.methods:
            try:
                attr = run_attribution_method(
                    method, model, batch["image"], condition_idx, level_idx, target,
                )
                attributions[method] = attr
                if maps_dir:
                    np.save(maps_dir / f"{sample_id}_{method}.npy", attr)
            except Exception as exc:
                if method not in skipped:
                    skipped[method] = str(exc)

        if not attributions:
            continue

        # ── Faithfulness ─────────────────────────────────────────────────
        if not args.skip_faithfulness:
            for method, attr in attributions.items():
                try:
                    del_auc = deletion_insertion_auc(
                        model, batch["image"], attr, condition_idx, level_idx, target,
                        mode="deletion", steps=args.faithfulness_steps,
                    )
                    ins_auc = deletion_insertion_auc(
                        model, batch["image"], attr, condition_idx, level_idx, target,
                        mode="insertion", steps=args.faithfulness_steps,
                    )
                    faithfulness_rows.append({
                        "sample_id": sample_id, "method": method,
                        "condition": condition, "label": label, "target": target,
                        "deletion_auc": del_auc, "insertion_auc": ins_auc,
                    })
                except Exception:
                    pass

        # ── Agreement ────────────────────────────────────────────────────
        if len(attributions) > 1:
            agreement = attribution_agreement(attributions)
            agreement_rows.append({
                "sample_id": sample_id, "condition": condition,
                "label": label, **agreement,
            })

        # ── Clinical alignment ───────────────────────────────────────────
        for method, attr in attributions.items():
            roi_score = proxy_roi_alignment(attr, condition=condition)
            clinical_rows.append({
                "sample_id": sample_id, "method": method,
                "condition": condition, "label": label,
                "proxy_roi_alignment": roi_score,
            })

        # ── Consistency ──────────────────────────────────────────────────
        if not args.skip_consistency and sample_idx < 200:
            for method in attributions:
                try:
                    cons = compute_consistency_for_sample(
                        model, batch["image"], condition_idx, level_idx, target,
                        method, n_augmentations=args.consistency_augmentations,
                    )
                    consistency_rows.append({
                        "sample_id": sample_id, "method": method,
                        "condition": condition,
                        "augmentation_iou": cons,
                    })
                except Exception:
                    pass

        # Periodic checkpoint
        if (sample_idx + 1) % 100 == 0:
            elapsed = (time.monotonic() - start_time) / 60.0
            print({"event": "xai_progress", "samples": sample_idx + 1,
                    "elapsed_min": round(elapsed, 1)}, flush=True)

    # ── Save results ─────────────────────────────────────────────────────
    _save_df(faithfulness_rows, args.output_dir / "faithfulness_metrics.csv")
    _save_df(agreement_rows, args.output_dir / "agreement_metrics.csv")
    _save_df(consistency_rows, args.output_dir / "consistency_metrics.csv")
    _save_df(clinical_rows, args.output_dir / "clinical_alignment.csv")

    # ── Aggregate summary ────────────────────────────────────────────────
    summary = _build_summary(faithfulness_rows, agreement_rows, consistency_rows, clinical_rows)
    write_json({"summary": summary, "skipped": skipped, "args": _args_dict(args)},
               args.output_dir / "xai_summary_v2.json")
    print({"summary": summary, "skipped": skipped})


def _save_df(rows: list[dict], path: Path) -> None:
    if rows:
        pd.DataFrame(rows).to_csv(path, index=False)
        print(f"Saved {len(rows)} rows to {path}")


def _build_summary(faith, agree, consist, clinical) -> dict:
    s: dict = {}
    if faith:
        df = pd.DataFrame(faith)
        s["faithfulness"] = df.groupby("method")[["deletion_auc", "insertion_auc"]].mean().to_dict(orient="index")
    if agree:
        df = pd.DataFrame(agree)
        for col in ["mean_spearman", "mean_top20_iou"]:
            if col in df.columns:
                s[col] = float(df[col].mean())
    if consist:
        df = pd.DataFrame(consist)
        s["consistency"] = df.groupby("method")["augmentation_iou"].mean().to_dict()
    if clinical:
        df = pd.DataFrame(clinical)
        s["clinical_alignment"] = df.groupby("method")["proxy_roi_alignment"].mean().to_dict()
        s["clinical_alignment_by_condition"] = (
            df.groupby(["method", "condition"])["proxy_roi_alignment"].mean()
            .unstack(level="condition").to_dict(orient="index")
        )
    return s


def _args_dict(args) -> dict:
    return {k: str(v) if isinstance(v, Path) else v
            for k, v in vars(args).items()}


if __name__ == "__main__":
    main()
